import streamlit as st
import json
import plotly.graph_objects as go
import numpy as np

# JSON 파일 경로
with open("Data/6types-output/voxel_data/voxel_022499.json", "r") as f:
    voxel_data = json.load(f)

# 복셀 타입에 따른 색상 매핑
color_mapping = {
    -1: "gray",
     0: "skyblue",
     1: "lightcoral",
     2: "lightcoral",
     3: "lightcoral",
     4: "violet",
     5: "lightcoral"
}

fig = go.Figure()

# 각 복셀을 plotly로 시각화
for voxel in voxel_data["voxel_node"]:
    if voxel["type"] == -1:
        continue
    x, y, z = voxel["coordinate"]  # (z, y, x) 순서
    dz, dy, dx = voxel["dimension"]
    
    # Plotly 좌표계 변환: x → y, y → z, z → x
    X = [y, y+dy]
    Y = [z, z+dz]
    Z = [x, x+dx]
    
    # 꼭짓점 8개
    vertices = np.array([
        [X[0], Y[0], Z[0]],
        [X[1], Y[0], Z[0]],
        [X[1], Y[1], Z[0]],
        [X[0], Y[1], Z[0]],
        [X[0], Y[0], Z[1]],
        [X[1], Y[0], Z[1]],
        [X[1], Y[1], Z[1]],
        [X[0], Y[1], Z[1]]
    ])
    
    # 면을 이루는 인덱스 (정육면체 기준)
    i, j, k = [], [], []
    faces = [
        [0, 1, 2, 3],  # bottom
        [4, 5, 6, 7],  # top
        [0, 1, 5, 4],  # front
        [2, 3, 7, 6],  # back
        [1, 2, 6, 5],  # right
        [0, 3, 7, 4]   # left
    ]
    
    # 각 면을 삼각형 2개로 나눠 Mesh3d 추가
    for face in faces:
        tri1, tri2 = face[0:3], [face[0], face[2], face[3]]
        i.extend([tri1[0], tri2[0]])
        j.extend([tri1[1], tri2[1]])
        k.extend([tri1[2], tri2[2]])

    fig.add_trace(go.Mesh3d(
        x=vertices[:, 0], y=vertices[:, 1], z=vertices[:, 2],
        i=i, j=j, k=k,
        opacity=0.8,
        color=color_mapping.get(voxel["type"], "white"),
        flatshading=True,
        showscale=False
    ))

# 축 라벨 설정
fig.update_layout(
    title="Voxel Graph Visualization",
    scene=dict(
        xaxis_title='Y',
        yaxis_title='Z',
        zaxis_title='X (Height)',
        xaxis=dict(range=[0, 50]),
        yaxis=dict(range=[0, 50]),
        zaxis=dict(range=[0, 50])
    ),
    margin=dict(r=0, l=0, b=0, t=30)
)

st.plotly_chart(fig, use_container_width=True)
