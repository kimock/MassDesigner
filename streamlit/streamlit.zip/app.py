import streamlit as st
import os

st.set_page_config(page_title="Routing Debug", layout="wide")

st.title("🔍 현재 Streamlit이 인식하는 페이지 라우팅 이름")

# Streamlit 내부에서 등록된 실제 라우팅 이름 표시
if hasattr(st, "_runtime"):
    pages = st._runtime._session_mgr._current_script_run._page_list._pages
    for k, v in pages.items():
        st.write(f"➡️ `{v['page_name']}` → `{k}`")
else:
    st.warning("❗ Streamlit 내부 페이지 정보를 가져올 수 없습니다.")
